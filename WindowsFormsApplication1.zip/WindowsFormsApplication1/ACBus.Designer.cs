﻿namespace WindowsFormsApplication1
{
    partial class ACBus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ACBus));
            this.SA2B = new System.Windows.Forms.Button();
            this.SJ2B = new System.Windows.Forms.Button();
            this.SI2B = new System.Windows.Forms.Button();
            this.SH2B = new System.Windows.Forms.Button();
            this.SG2B = new System.Windows.Forms.Button();
            this.SF2B = new System.Windows.Forms.Button();
            this.SE2B = new System.Windows.Forms.Button();
            this.SD2B = new System.Windows.Forms.Button();
            this.SC2B = new System.Windows.Forms.Button();
            this.SB2B = new System.Windows.Forms.Button();
            this.SA3B = new System.Windows.Forms.Button();
            this.SJ3B = new System.Windows.Forms.Button();
            this.SI3B = new System.Windows.Forms.Button();
            this.SH3B = new System.Windows.Forms.Button();
            this.SG3B = new System.Windows.Forms.Button();
            this.SF3B = new System.Windows.Forms.Button();
            this.SE3B = new System.Windows.Forms.Button();
            this.SD3B = new System.Windows.Forms.Button();
            this.SC3B = new System.Windows.Forms.Button();
            this.SB3B = new System.Windows.Forms.Button();
            this.SA1B = new System.Windows.Forms.Button();
            this.SJ1B = new System.Windows.Forms.Button();
            this.SI1B = new System.Windows.Forms.Button();
            this.SH1B = new System.Windows.Forms.Button();
            this.SG1B = new System.Windows.Forms.Button();
            this.SF1B = new System.Windows.Forms.Button();
            this.SE1B = new System.Windows.Forms.Button();
            this.SD1B = new System.Windows.Forms.Button();
            this.SC1B = new System.Windows.Forms.Button();
            this.SB1B = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ACBusL = new System.Windows.Forms.Label();
            this.NextB = new System.Windows.Forms.Button();
            this.BackB = new System.Windows.Forms.Button();
            this.SeatPriceL = new System.Windows.Forms.Label();
            this.SpriceBox = new System.Windows.Forms.TextBox();
            this.BDTL = new System.Windows.Forms.Label();
            this.SeatBox = new System.Windows.Forms.RichTextBox();
            this.SelectAgainB = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SA2B
            // 
            this.SA2B.Location = new System.Drawing.Point(440, 87);
            this.SA2B.Name = "SA2B";
            this.SA2B.Size = new System.Drawing.Size(34, 23);
            this.SA2B.TabIndex = 0;
            this.SA2B.Text = "A2";
            this.SA2B.UseVisualStyleBackColor = true;
            this.SA2B.Click += new System.EventHandler(this.SA2B_Click);
            // 
            // SJ2B
            // 
            this.SJ2B.Location = new System.Drawing.Point(440, 348);
            this.SJ2B.Name = "SJ2B";
            this.SJ2B.Size = new System.Drawing.Size(34, 23);
            this.SJ2B.TabIndex = 1;
            this.SJ2B.Text = "J2";
            this.SJ2B.UseVisualStyleBackColor = true;
            this.SJ2B.Click += new System.EventHandler(this.SJ2B_Click);
            // 
            // SI2B
            // 
            this.SI2B.Location = new System.Drawing.Point(440, 319);
            this.SI2B.Name = "SI2B";
            this.SI2B.Size = new System.Drawing.Size(34, 23);
            this.SI2B.TabIndex = 2;
            this.SI2B.Text = "I2";
            this.SI2B.UseVisualStyleBackColor = true;
            this.SI2B.Click += new System.EventHandler(this.SI2B_Click);
            // 
            // SH2B
            // 
            this.SH2B.Location = new System.Drawing.Point(440, 290);
            this.SH2B.Name = "SH2B";
            this.SH2B.Size = new System.Drawing.Size(34, 23);
            this.SH2B.TabIndex = 3;
            this.SH2B.Text = "H2";
            this.SH2B.UseVisualStyleBackColor = true;
            this.SH2B.Click += new System.EventHandler(this.SH2B_Click);
            // 
            // SG2B
            // 
            this.SG2B.Location = new System.Drawing.Point(440, 261);
            this.SG2B.Name = "SG2B";
            this.SG2B.Size = new System.Drawing.Size(34, 23);
            this.SG2B.TabIndex = 4;
            this.SG2B.Text = "G2";
            this.SG2B.UseVisualStyleBackColor = true;
            this.SG2B.Click += new System.EventHandler(this.SG2B_Click);
            // 
            // SF2B
            // 
            this.SF2B.Location = new System.Drawing.Point(440, 232);
            this.SF2B.Name = "SF2B";
            this.SF2B.Size = new System.Drawing.Size(34, 23);
            this.SF2B.TabIndex = 5;
            this.SF2B.Text = "F2";
            this.SF2B.UseVisualStyleBackColor = true;
            this.SF2B.Click += new System.EventHandler(this.SF2B_Click);
            // 
            // SE2B
            // 
            this.SE2B.Location = new System.Drawing.Point(440, 203);
            this.SE2B.Name = "SE2B";
            this.SE2B.Size = new System.Drawing.Size(34, 23);
            this.SE2B.TabIndex = 6;
            this.SE2B.Text = "E2";
            this.SE2B.UseVisualStyleBackColor = true;
            this.SE2B.Click += new System.EventHandler(this.SE2B_Click);
            // 
            // SD2B
            // 
            this.SD2B.Location = new System.Drawing.Point(440, 174);
            this.SD2B.Name = "SD2B";
            this.SD2B.Size = new System.Drawing.Size(34, 23);
            this.SD2B.TabIndex = 7;
            this.SD2B.Text = "D2";
            this.SD2B.UseVisualStyleBackColor = true;
            this.SD2B.Click += new System.EventHandler(this.SD2B_Click);
            // 
            // SC2B
            // 
            this.SC2B.Location = new System.Drawing.Point(440, 145);
            this.SC2B.Name = "SC2B";
            this.SC2B.Size = new System.Drawing.Size(34, 23);
            this.SC2B.TabIndex = 8;
            this.SC2B.Text = "C2";
            this.SC2B.UseVisualStyleBackColor = true;
            this.SC2B.Click += new System.EventHandler(this.SC2B_Click);
            // 
            // SB2B
            // 
            this.SB2B.Location = new System.Drawing.Point(440, 116);
            this.SB2B.Name = "SB2B";
            this.SB2B.Size = new System.Drawing.Size(34, 23);
            this.SB2B.TabIndex = 9;
            this.SB2B.Text = "B2";
            this.SB2B.UseVisualStyleBackColor = true;
            this.SB2B.Click += new System.EventHandler(this.SB2B_Click);
            // 
            // SA3B
            // 
            this.SA3B.Location = new System.Drawing.Point(480, 87);
            this.SA3B.Name = "SA3B";
            this.SA3B.Size = new System.Drawing.Size(34, 23);
            this.SA3B.TabIndex = 0;
            this.SA3B.Text = "A3";
            this.SA3B.UseVisualStyleBackColor = true;
            this.SA3B.Click += new System.EventHandler(this.SA3B_Click);
            // 
            // SJ3B
            // 
            this.SJ3B.Location = new System.Drawing.Point(480, 348);
            this.SJ3B.Name = "SJ3B";
            this.SJ3B.Size = new System.Drawing.Size(34, 23);
            this.SJ3B.TabIndex = 1;
            this.SJ3B.Text = "J3";
            this.SJ3B.UseVisualStyleBackColor = true;
            this.SJ3B.Click += new System.EventHandler(this.SJ3B_Click);
            // 
            // SI3B
            // 
            this.SI3B.Location = new System.Drawing.Point(480, 319);
            this.SI3B.Name = "SI3B";
            this.SI3B.Size = new System.Drawing.Size(34, 23);
            this.SI3B.TabIndex = 2;
            this.SI3B.Text = "I3";
            this.SI3B.UseVisualStyleBackColor = true;
            this.SI3B.Click += new System.EventHandler(this.SI3B_Click);
            // 
            // SH3B
            // 
            this.SH3B.Location = new System.Drawing.Point(480, 290);
            this.SH3B.Name = "SH3B";
            this.SH3B.Size = new System.Drawing.Size(34, 23);
            this.SH3B.TabIndex = 3;
            this.SH3B.Text = "H3";
            this.SH3B.UseVisualStyleBackColor = true;
            this.SH3B.Click += new System.EventHandler(this.SH3B_Click);
            // 
            // SG3B
            // 
            this.SG3B.Location = new System.Drawing.Point(480, 261);
            this.SG3B.Name = "SG3B";
            this.SG3B.Size = new System.Drawing.Size(34, 23);
            this.SG3B.TabIndex = 4;
            this.SG3B.Text = "G3";
            this.SG3B.UseVisualStyleBackColor = true;
            this.SG3B.Click += new System.EventHandler(this.SG3B_Click);
            // 
            // SF3B
            // 
            this.SF3B.Location = new System.Drawing.Point(480, 232);
            this.SF3B.Name = "SF3B";
            this.SF3B.Size = new System.Drawing.Size(34, 23);
            this.SF3B.TabIndex = 5;
            this.SF3B.Text = "F3";
            this.SF3B.UseVisualStyleBackColor = true;
            this.SF3B.Click += new System.EventHandler(this.SF3B_Click);
            // 
            // SE3B
            // 
            this.SE3B.Location = new System.Drawing.Point(480, 203);
            this.SE3B.Name = "SE3B";
            this.SE3B.Size = new System.Drawing.Size(34, 23);
            this.SE3B.TabIndex = 6;
            this.SE3B.Text = "E3";
            this.SE3B.UseVisualStyleBackColor = true;
            this.SE3B.Click += new System.EventHandler(this.SE3B_Click);
            // 
            // SD3B
            // 
            this.SD3B.Location = new System.Drawing.Point(480, 174);
            this.SD3B.Name = "SD3B";
            this.SD3B.Size = new System.Drawing.Size(34, 23);
            this.SD3B.TabIndex = 7;
            this.SD3B.Text = "D3";
            this.SD3B.UseVisualStyleBackColor = true;
            this.SD3B.Click += new System.EventHandler(this.SD3B_Click);
            // 
            // SC3B
            // 
            this.SC3B.Location = new System.Drawing.Point(480, 145);
            this.SC3B.Name = "SC3B";
            this.SC3B.Size = new System.Drawing.Size(34, 23);
            this.SC3B.TabIndex = 8;
            this.SC3B.Text = "C3";
            this.SC3B.UseVisualStyleBackColor = true;
            this.SC3B.Click += new System.EventHandler(this.SC3B_Click);
            // 
            // SB3B
            // 
            this.SB3B.Location = new System.Drawing.Point(480, 116);
            this.SB3B.Name = "SB3B";
            this.SB3B.Size = new System.Drawing.Size(34, 23);
            this.SB3B.TabIndex = 9;
            this.SB3B.Text = "B3";
            this.SB3B.UseVisualStyleBackColor = true;
            this.SB3B.Click += new System.EventHandler(this.SB3B_Click);
            // 
            // SA1B
            // 
            this.SA1B.BackColor = System.Drawing.Color.Gainsboro;
            this.SA1B.Location = new System.Drawing.Point(345, 87);
            this.SA1B.Name = "SA1B";
            this.SA1B.Size = new System.Drawing.Size(34, 23);
            this.SA1B.TabIndex = 0;
            this.SA1B.Text = "A1";
            this.SA1B.UseVisualStyleBackColor = false;
            this.SA1B.Click += new System.EventHandler(this.SA1B_Click);
            // 
            // SJ1B
            // 
            this.SJ1B.Location = new System.Drawing.Point(345, 348);
            this.SJ1B.Name = "SJ1B";
            this.SJ1B.Size = new System.Drawing.Size(34, 23);
            this.SJ1B.TabIndex = 1;
            this.SJ1B.Text = "J1";
            this.SJ1B.UseVisualStyleBackColor = true;
            this.SJ1B.Click += new System.EventHandler(this.SJ1B_Click);
            // 
            // SI1B
            // 
            this.SI1B.Location = new System.Drawing.Point(345, 319);
            this.SI1B.Name = "SI1B";
            this.SI1B.Size = new System.Drawing.Size(34, 23);
            this.SI1B.TabIndex = 2;
            this.SI1B.Text = "I1";
            this.SI1B.UseVisualStyleBackColor = true;
            this.SI1B.Click += new System.EventHandler(this.SI1B_Click);
            // 
            // SH1B
            // 
            this.SH1B.Location = new System.Drawing.Point(345, 290);
            this.SH1B.Name = "SH1B";
            this.SH1B.Size = new System.Drawing.Size(34, 23);
            this.SH1B.TabIndex = 3;
            this.SH1B.Text = "H1";
            this.SH1B.UseVisualStyleBackColor = true;
            this.SH1B.Click += new System.EventHandler(this.SH1B_Click);
            // 
            // SG1B
            // 
            this.SG1B.Location = new System.Drawing.Point(345, 261);
            this.SG1B.Name = "SG1B";
            this.SG1B.Size = new System.Drawing.Size(34, 23);
            this.SG1B.TabIndex = 4;
            this.SG1B.Text = "G1";
            this.SG1B.UseVisualStyleBackColor = true;
            this.SG1B.Click += new System.EventHandler(this.SG1B_Click);
            // 
            // SF1B
            // 
            this.SF1B.Location = new System.Drawing.Point(345, 232);
            this.SF1B.Name = "SF1B";
            this.SF1B.Size = new System.Drawing.Size(34, 23);
            this.SF1B.TabIndex = 5;
            this.SF1B.Text = "F1";
            this.SF1B.UseVisualStyleBackColor = true;
            this.SF1B.Click += new System.EventHandler(this.SF1B_Click);
            // 
            // SE1B
            // 
            this.SE1B.Location = new System.Drawing.Point(345, 203);
            this.SE1B.Name = "SE1B";
            this.SE1B.Size = new System.Drawing.Size(34, 23);
            this.SE1B.TabIndex = 6;
            this.SE1B.Text = "E1";
            this.SE1B.UseVisualStyleBackColor = true;
            this.SE1B.Click += new System.EventHandler(this.SE1B_Click);
            // 
            // SD1B
            // 
            this.SD1B.Location = new System.Drawing.Point(345, 174);
            this.SD1B.Name = "SD1B";
            this.SD1B.Size = new System.Drawing.Size(34, 23);
            this.SD1B.TabIndex = 7;
            this.SD1B.Text = "D1";
            this.SD1B.UseVisualStyleBackColor = true;
            this.SD1B.Click += new System.EventHandler(this.SD1B_Click);
            // 
            // SC1B
            // 
            this.SC1B.Location = new System.Drawing.Point(345, 145);
            this.SC1B.Name = "SC1B";
            this.SC1B.Size = new System.Drawing.Size(34, 23);
            this.SC1B.TabIndex = 8;
            this.SC1B.Text = "C1";
            this.SC1B.UseVisualStyleBackColor = true;
            this.SC1B.Click += new System.EventHandler(this.SC1B_Click);
            // 
            // SB1B
            // 
            this.SB1B.Location = new System.Drawing.Point(345, 116);
            this.SB1B.Name = "SB1B";
            this.SB1B.Size = new System.Drawing.Size(34, 23);
            this.SB1B.TabIndex = 9;
            this.SB1B.Text = "B1";
            this.SB1B.UseVisualStyleBackColor = true;
            this.SB1B.Click += new System.EventHandler(this.SB1B_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(38, 87);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(240, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // ACBusL
            // 
            this.ACBusL.AutoSize = true;
            this.ACBusL.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ACBusL.Location = new System.Drawing.Point(376, 27);
            this.ACBusL.Name = "ACBusL";
            this.ACBusL.Size = new System.Drawing.Size(98, 29);
            this.ACBusL.TabIndex = 11;
            this.ACBusL.Text = "AC Bus";
            // 
            // NextB
            // 
            this.NextB.Location = new System.Drawing.Point(480, 384);
            this.NextB.Name = "NextB";
            this.NextB.Size = new System.Drawing.Size(75, 23);
            this.NextB.TabIndex = 12;
            this.NextB.Text = "Next";
            this.NextB.UseVisualStyleBackColor = true;
            this.NextB.Click += new System.EventHandler(this.NextB_Click);
            // 
            // BackB
            // 
            this.BackB.Location = new System.Drawing.Point(304, 384);
            this.BackB.Name = "BackB";
            this.BackB.Size = new System.Drawing.Size(75, 23);
            this.BackB.TabIndex = 13;
            this.BackB.Text = "Back";
            this.BackB.UseVisualStyleBackColor = true;
            this.BackB.Click += new System.EventHandler(this.BackB_Click);
            // 
            // SeatPriceL
            // 
            this.SeatPriceL.AutoSize = true;
            this.SeatPriceL.Location = new System.Drawing.Point(51, 39);
            this.SeatPriceL.Name = "SeatPriceL";
            this.SeatPriceL.Size = new System.Drawing.Size(56, 13);
            this.SeatPriceL.TabIndex = 14;
            this.SeatPriceL.Text = "Seat Price";
            // 
            // SpriceBox
            // 
            this.SpriceBox.Enabled = false;
            this.SpriceBox.Location = new System.Drawing.Point(113, 36);
            this.SpriceBox.Name = "SpriceBox";
            this.SpriceBox.Size = new System.Drawing.Size(58, 20);
            this.SpriceBox.TabIndex = 15;
            // 
            // BDTL
            // 
            this.BDTL.AutoSize = true;
            this.BDTL.Location = new System.Drawing.Point(177, 39);
            this.BDTL.Name = "BDTL";
            this.BDTL.Size = new System.Drawing.Size(56, 13);
            this.BDTL.TabIndex = 16;
            this.BDTL.Text = "BDT each";
            // 
            // SeatBox
            // 
            this.SeatBox.Enabled = false;
            this.SeatBox.Location = new System.Drawing.Point(38, 314);
            this.SeatBox.Name = "SeatBox";
            this.SeatBox.Size = new System.Drawing.Size(240, 57);
            this.SeatBox.TabIndex = 17;
            this.SeatBox.Text = "";
            this.SeatBox.TextChanged += new System.EventHandler(this.SeatBox_TextChanged);
            // 
            // SelectAgainB
            // 
            this.SelectAgainB.Location = new System.Drawing.Point(392, 384);
            this.SelectAgainB.Name = "SelectAgainB";
            this.SelectAgainB.Size = new System.Drawing.Size(75, 23);
            this.SelectAgainB.TabIndex = 18;
            this.SelectAgainB.Text = "Select Again";
            this.SelectAgainB.UseVisualStyleBackColor = true;
            this.SelectAgainB.Click += new System.EventHandler(this.SelectAgainB_Click);
            // 
            // ACBus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleTurquoise;
            this.ClientSize = new System.Drawing.Size(570, 432);
            this.Controls.Add(this.SelectAgainB);
            this.Controls.Add(this.SeatBox);
            this.Controls.Add(this.BDTL);
            this.Controls.Add(this.SpriceBox);
            this.Controls.Add(this.SeatPriceL);
            this.Controls.Add(this.BackB);
            this.Controls.Add(this.NextB);
            this.Controls.Add(this.ACBusL);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SB3B);
            this.Controls.Add(this.SB1B);
            this.Controls.Add(this.SB2B);
            this.Controls.Add(this.SC3B);
            this.Controls.Add(this.SC1B);
            this.Controls.Add(this.SC2B);
            this.Controls.Add(this.SD3B);
            this.Controls.Add(this.SD1B);
            this.Controls.Add(this.SD2B);
            this.Controls.Add(this.SE3B);
            this.Controls.Add(this.SE1B);
            this.Controls.Add(this.SE2B);
            this.Controls.Add(this.SF3B);
            this.Controls.Add(this.SF1B);
            this.Controls.Add(this.SF2B);
            this.Controls.Add(this.SG3B);
            this.Controls.Add(this.SG1B);
            this.Controls.Add(this.SG2B);
            this.Controls.Add(this.SH3B);
            this.Controls.Add(this.SH1B);
            this.Controls.Add(this.SH2B);
            this.Controls.Add(this.SI3B);
            this.Controls.Add(this.SI1B);
            this.Controls.Add(this.SI2B);
            this.Controls.Add(this.SJ3B);
            this.Controls.Add(this.SJ1B);
            this.Controls.Add(this.SJ2B);
            this.Controls.Add(this.SA3B);
            this.Controls.Add(this.SA1B);
            this.Controls.Add(this.SA2B);
            this.Name = "ACBus";
            this.Text = "ACBus";
            this.Load += new System.EventHandler(this.SeatPlanpage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SA2B;
        private System.Windows.Forms.Button SJ2B;
        private System.Windows.Forms.Button SI2B;
        private System.Windows.Forms.Button SH2B;
        private System.Windows.Forms.Button SG2B;
        private System.Windows.Forms.Button SF2B;
        private System.Windows.Forms.Button SE2B;
        private System.Windows.Forms.Button SD2B;
        private System.Windows.Forms.Button SC2B;
        private System.Windows.Forms.Button SB2B;
        private System.Windows.Forms.Button SA3B;
        private System.Windows.Forms.Button SJ3B;
        private System.Windows.Forms.Button SI3B;
        private System.Windows.Forms.Button SH3B;
        private System.Windows.Forms.Button SG3B;
        private System.Windows.Forms.Button SF3B;
        private System.Windows.Forms.Button SE3B;
        private System.Windows.Forms.Button SD3B;
        private System.Windows.Forms.Button SC3B;
        private System.Windows.Forms.Button SB3B;
        private System.Windows.Forms.Button SA1B;
        private System.Windows.Forms.Button SJ1B;
        private System.Windows.Forms.Button SI1B;
        private System.Windows.Forms.Button SH1B;
        private System.Windows.Forms.Button SG1B;
        private System.Windows.Forms.Button SF1B;
        private System.Windows.Forms.Button SE1B;
        private System.Windows.Forms.Button SD1B;
        private System.Windows.Forms.Button SC1B;
        private System.Windows.Forms.Button SB1B;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label ACBusL;
        private System.Windows.Forms.Button NextB;
        private System.Windows.Forms.Button BackB;
        private System.Windows.Forms.Label SeatPriceL;
        private System.Windows.Forms.TextBox SpriceBox;
        private System.Windows.Forms.Label BDTL;
        private System.Windows.Forms.RichTextBox SeatBox;
        private System.Windows.Forms.Button SelectAgainB;
    }
}